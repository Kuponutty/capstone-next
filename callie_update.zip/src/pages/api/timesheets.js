
import { Sequelize } from "sequelize";
import * as tedious from "tedious";

const sequelize = new Sequelize("timesheetdb", "timesheetadmin", "JmDeCp#1", {
  host: "sheetserv.database.windows.net",
  dialect: "mssql",
  dialectModule: tedious,
});

export default async function handler(req, res) {
  try {
    const startDate = "2024-11-18";
    const periodSQL = `SELECT id FROM reporting_periods WHERE start_date = '${startDate}'`;
    const periodResult = await sequelize.query(periodSQL, { type: Sequelize.QueryTypes.SELECT });
    const currentPeriodID = periodResult[0].id;

    const sheetsSQL = `SELECT * FROM timesheets WHERE period_id = '${currentPeriodID}'`;
    const timesheets = await sequelize.query(sheetsSQL, { type: Sequelize.QueryTypes.SELECT });

    res.status(200).json(timesheets);
  } catch (error) {
    console.error("Error fetching timesheets:", error);
    res.status(500).json({ error: "Failed to fetch timesheets" });
  }
}