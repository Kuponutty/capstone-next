"use client";

import React, { useEffect, useState } from "react";

function GetTimesheet() {
  const [timesheets, setTimesheets] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchTimesheets = async () => {
      try {
        const response = await fetch("/api/timesheets");
        if (!response.ok) {
          throw new Error("Failed to fetch timesheets");
        }
        const data = await response.json();
        setTimesheets(data);
      } catch (err) {
        setError(err.message);
      }
    };

    fetchTimesheets();
  }, []);

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div>
      <h1>Timesheets</h1>
      <table>
        <thead>
          <tr>
            <th>User W#</th>
          </tr>
        </thead>
        <tbody>
          {timesheets.map((sheet, index) => (
            <tr key={index}>
              <td>{sheet.user_wid}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default GetTimesheet;

// import Image from "next/image";
// import * as tedious from 'tedious';

// async function GetTimesheet() {
//   const ExcelJS = require('exceljs');
//   const {Sequelize, QueryTypes} = require('sequelize');
//   const sequelize = new Sequelize('timesheetdb', 'timesheetadmin', 'JmDeCp#1', {
//     host: 'sheetserv.database.windows.net',
//     dialect: 'mssql',
//     dialectModule: tedious
//   });

//   const startDate = '2024-11-18';
//   const periodSQL = `SELECT id FROM reporting_periods WHERE start_date = '${startDate}'`;
//   const periodResult = await sequelize.query(periodSQL, {
//     type: QueryTypes.SELECT,
//   })
//   const currentPeriodID = periodResult[0].id;
//   console.log(currentPeriodID);

//   const sheetsSQL = `SELECT * FROM timesheets WHERE period_id = '${currentPeriodID}'`;
//   const timesheets = await sequelize.query(sheetsSQL , {
//     type: QueryTypes.SELECT,
// });

// const workbook = new ExcelJS.Workbook();
// const timesheetsWorksheet = workbook.addWorksheet('Timesheets');

// timesheetsWorksheet.columns = [
//   {header: 'W#', key: 'user_wid'},
// ];


// timesheetsWorksheet.addRows(timesheets);

// await workbook.xlsx.writeFile('sheets.xlsx');

//   return (
//     <>
//       <div>
//         <h1>Yea</h1>
//       </div>
//     </>
//   );
// }

// export default GetTimesheet